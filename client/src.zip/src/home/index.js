import {HttpClient, json} from 'aurelia-fetch-client';
import environment from '../environment';

export class Home {
	userData = {};

	constructor() {
		this.myOptions = ["Loeng", "Harjutus", "Praktikum", "Loeng + Harjutus", "Harjutus + Praktikum", "Loeng + Harjutus + Praktikum"];
	}

	addSubject() {
		let client = new HttpClient();
		let url =  environment.rest_url + ":" + environment.rest_port + '/subject/add';
		console.log("Saadud url: " + url);
		console.log("Serverile saadetakse: " + JSON.stringify(this.userData));
	    client.fetch(url, {
	    	'method': "POST",
	    	'body': json(this.userData)
	    })
	        .then(response => {
				if (!response.ok) {
					alert("Palun kontrolli sisendit.");
				} else {
					alert("Aine edukalt lisatud.");
				}
				response.json()
		});
			console.log("addSubject method executed!");
	}

	onSignIn(googleUser) {
		// Useful data for your client-side scripts:
		var profile = googleUser.getBasicProfile();
		console.log("ID: " + profile.getId()); // Don't send this directly to your server!
		console.log('Full Name: ' + profile.getName());
		console.log('Given Name: ' + profile.getGivenName());
		console.log('Family Name: ' + profile.getFamilyName());
		console.log("Image URL: " + profile.getImageUrl());
		console.log("Email: " + profile.getEmail());

		// The ID token you need to pass to your backend:
		var id_token = googleUser.getAuthResponse().id_token;
		console.log("ID Token: " + id_token);
	};
	signOut() {
		var auth2 = gapi.auth2.getAuthInstance();
		auth2.signOut().then(function () {
			console.log('User signed out.');
		});
	}
}
