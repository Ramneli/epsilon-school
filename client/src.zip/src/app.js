export class App {
	constructor() {
		this.message = 'Epsilon-School';
    }
    
    message = 'Not signed in.';

  signinSuccess(googleUser) {
    const name = googleUser.getBasicProfile().getName();
    this.message = `Signed in: ${name}`;
  }

  signinError(error) {
    this.message = `Error: ${error}`;
  }

    configureRouter(config, router) {
        this.router = router;
        config.title = 'Aurelia Config Title';
        config.map([
            { route: 'homework',        name: 'homework',      moduleId: 'homework/homework', nav: true, title: 'Ülesanded'},
            { route: 'addtask',        name: 'addtask',      moduleId: 'addtask/addtask', nav: true, title: 'Lisa ülesanne'},
            { route: 'addnewsubject',        name: 'addnewsubject',      moduleId: 'addnewsubject/addnewsubject', nav: true, title: 'Lisa aine tunniplaani'},
            { route: ['', 'home'],       name: 'home',       moduleId: 'home/index', nav: true, title: 'Loo aine'}

        ]);
      }
}
