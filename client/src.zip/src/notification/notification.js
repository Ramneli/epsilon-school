export class Homework {
	
}