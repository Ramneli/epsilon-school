export default {
  debug: true,
  testing: true,
  rest_url: 'http://localhost',
  rest_port: '8080'
};
